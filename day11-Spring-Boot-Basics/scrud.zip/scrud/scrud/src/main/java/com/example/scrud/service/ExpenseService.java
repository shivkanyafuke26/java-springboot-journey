package com.example.scrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.scrud.entity.Expense;
import com.example.scrud.repository.ExpenseRepository;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository repo;

    public Expense addExpense(Expense expense) {
        return repo.save(expense);
    }

    public List<Expense> getAllExpenses() {
        return repo.findAll();
    }

    public void deleteExpense(Long id) {
        repo.deleteById(id);
    }

    public double getTotalExpense() {
        return repo.findAll()
                .stream()
                .mapToDouble(Expense::getAmount)
                .sum();
    }
}