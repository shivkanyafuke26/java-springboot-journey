package com.example.scrud.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.scrud.entity.Expense;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
}