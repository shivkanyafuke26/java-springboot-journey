package com.example.scrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
