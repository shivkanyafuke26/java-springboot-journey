package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {

        Alien a1 = new Alien();
        a1.setAid(101);
        a1.setAname("Navin");
        a1.setTech("Java");

        Configuration config = new Configuration();
        config.configure();

        SessionFactory factory = config.buildSessionFactory();
        Session session = factory.openSession();

        // start transaction
        session.beginTransaction();

        // save object
        session.persist(a1);

        // commit transaction
        session.getTransaction().commit();

        session.close();
        factory.close();

        System.out.println("Data inserted successfully!");
    }
}