package org.example;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");

        try {
            SessionFactory sessionFactory =
                    new Configuration().configure().buildSessionFactory();

            System.out.println("Hibernate setup successful!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}